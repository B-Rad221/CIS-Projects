#ifndef A3FUNCTIONS_H
#define A3FUNCTIONS_H
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include <unistd.h>
#include <dirent.h>
#include <sys/stat.h>
#include <pwd.h>
#include <sys/types.h>
#include <grp.h>
#include <time.h>
#include <limits.h>
#define MAX_FILE_NUMBER 200

void read_dir(char *directory, int mode, int level);
int alphabetical_compare(char *first, char *second, int i);
void sort_dir(struct dirent **filelist, DIR *dir, int mode, int mask);
void print_file_list(struct dirent **filelist, char *path, int mode);
void read_system(char *directory, char c, int level);

#endif