#include"a4.h"

int main(int argc, const char *argv[])
{
	if(argc != 2)
	{
		fprintf(stderr, "ERROR: The number of arguments must be 1.\n");
		return(-1);
	}
	char cwd[PATH_MAX];
	if(getcwd(cwd, sizeof(cwd)) != NULL)
	{
		strcat(cwd, "/");
		strcat(cwd, argv[1]);
	}
	else
	{
		perror("getcwd()");
       	return -1;
    }
    printf("<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n<meta charset=\"utf-8\">\n</head>\n<body>\n<center>\n<div class=\"mermaid\">\n");
    printf("graph TD\n");
    printf("A[%s]\n", argv[1]);
    read_system(cwd, 'B', 0);
    printf("</div>\n</center>\n<script src=\"mermaid8.9.1.min.js\"></script>\n<script>\nmermaid.initialize({startOnLoad:true});</script>\n</body>\n</html>\n");
}