#include "a4.h"

void read_dir(char *directory, int mode, int level)
{
	DIR *dir = opendir(directory);
	if(dir == NULL)
	{
		perror("opendir()");
		return;
	}
	level++;
	char tmp[PATH_MAX];
	if(level == 1)
	{
		strcpy(tmp, directory);
	}
	else
	{
		int j, end;
		for(j = 0; directory[j] != '\0'; j++);
		end = j;
		while(j > 0)
		{
			if(directory[j] == '/')
			{
				j++;
				strncpy(tmp, directory + j, end - j); // Copies from after the slash to the end of the directory string
				tmp[end - j] = '\0';
				break;
			}
			j--;
		}
	}
	printf("Level %d: %s\n", level, tmp);
	struct dirent *filelist[MAX_FILE_NUMBER] = {NULL};
	struct dirent *dirlist[MAX_FILE_NUMBER] = {NULL};
	sort_dir(filelist, dir, mode, 0);
	sort_dir(dirlist, dir, mode, 1);
	if(dirlist[0] != NULL)
	{
		printf("Directories\n");
		print_file_list(dirlist, directory, mode);
	}
	if(filelist[0] != NULL)
	{
		printf("Files\n");
		print_file_list(filelist, directory, mode);
	}
	int i;
	strcpy(tmp, directory);
	for(i = 0; dirlist[i] != NULL; i++)
	{
		strcpy(directory, tmp);
		strcat(directory, "/");
		read_dir(strcat(directory, dirlist[i]->d_name), mode, level);
	}
	closedir(dir);
}

int alphabetical_compare(char *first, char *second, int i)
{
	int ret;
	if(first[i] == '\0' || second[i] == '\0')
	{
		return(1);
	}
	if(first[i] == second[i])
	{
		i++;
		ret = alphabetical_compare(first, second, i);
	}
	else if(first[i] > 64 && first[i] < 91 && second[i] > 64 && second[i] < 91)
	{
		if(first[i] < second[i])
		{
			ret = 1;
		}
	}
	else if(first[i] > 64 && first[i] < 91)
	{
		if((first[i]+32) < second[i])
		{
			ret = 1;
		}
		else
		{
			ret = 0;
		}
	}
	else if(second[i] > 64 && second[i] < 91)
	{
		if(first[i] < (second[i]+32))
		{
			ret = 1;
		}
		else
		{
			ret = 0;
		}
	}
	else if(first[i] < second[i])
	{
		ret = 1;
	}
	else
	{
		ret = 0;
	}
	return(ret);
}

void sort_dir(struct dirent **filelist, DIR *dir, int mode, int mask)
{
	int n = 0;
	while((filelist[n] = readdir(dir)) != NULL)
	{
		if(filelist[n]->d_name[0] != '.' && ((mask) ? (filelist[n]->d_type == DT_DIR) : (filelist[n]->d_type != DT_DIR))) // Ignores hidden files and directories or non-directories
		{
			if(n != 0)
			{
				if(mode)
				{
					int j = n;
					while(alphabetical_compare(filelist[j]->d_name, filelist[j-1]->d_name, 0))
					{
						struct dirent *tmp;
						tmp = filelist[j-1];
						filelist[j-1] = filelist[j];
						filelist[j] = tmp;
						if(j > 1)
						{
							j--;
						}
						else
						{
							break;
						}
					}
				}
				else
				{
					int j = n;
					while(filelist[j]->d_ino < filelist[j-1]->d_ino)
					{
						struct dirent *tmp;
						tmp = filelist[j-1];
						filelist[j-1] = filelist[j];
						filelist[j] = tmp;
						if(j > 1)
						{
							j--;
						}
					}
				}
			}
		}
		else
		{
			n--;
		}
		n++;
	}
	rewinddir(dir);
}

void print_file_list(struct dirent **filelist, char *path, int mode)
{
	int i, status;
	struct stat buffer;
	for(i = 0; filelist[i] != NULL; i++)
	{
		char tmp[250];
		strcpy(tmp, path);
		strcat(tmp, "/");
		status = stat(strcat(tmp, filelist[i]->d_name), &buffer);
		if(status != -1)
		{
			if(mode)
			{
				struct passwd *pwd;
				if ((pwd = getpwuid(buffer.st_uid)) != NULL)
				{
				    printf("%s", pwd->pw_name);
				}
				else
				{
				    printf("%d", buffer.st_uid);
				}
				struct group *grp;
				if ((grp = getgrgid(buffer.st_gid)) != NULL)
				{
				 	printf(" (%s)", grp->gr_name);
				}
				else
				{
   					printf(" (%d)", buffer.st_gid);
				}
				printf("\t%ld\t", buffer.st_ino);
				// Code found here: https://stackoverflow.com/questions/10323060/printing-file-permissions-like-ls-l-using-stat2-in-c
				printf( (S_ISDIR(buffer.st_mode)) ? "d" : "-");
			    printf( (buffer.st_mode & S_IRUSR) ? "r" : "-");
			    printf( (buffer.st_mode & S_IWUSR) ? "w" : "-");
			    printf( (buffer.st_mode & S_IXUSR) ? "x" : "-");
			    printf( (buffer.st_mode & S_IRGRP) ? "r" : "-");
			    printf( (buffer.st_mode & S_IWGRP) ? "w" : "-");
			    printf( (buffer.st_mode & S_IXGRP) ? "x" : "-");
			    printf( (buffer.st_mode & S_IROTH) ? "r" : "-");
			    printf( (buffer.st_mode & S_IWOTH) ? "w" : "-");
			    printf( (buffer.st_mode & S_IXOTH) ? "x" : "-");
			    printf("\t%ld\t%s\n", buffer.st_size, filelist[i]->d_name);
			    char mod_time[50];
			    char access_time[50];
			    // Code found here: https://stackoverflow.com/questions/43838930/last-modified-time-of-file-in-c/43839285
			    strftime(mod_time, 50, "%Y-%m-%d %H:%M:%S", localtime(&buffer.st_mtime));
			    strftime(access_time, 50, "%Y-%m-%d %H:%M:%S", localtime(&buffer.st_mtime));
			    printf("%s\t%s\n", access_time, mod_time);
			}
			else
			{
				printf("%ld:\t%ld\t%ld\t%ld\t%s\n", filelist[i]->d_ino, buffer.st_size, buffer.st_blocks, buffer.st_size/512, filelist[i]->d_name);
			}
		}
	}		
	printf("\n");
}

void read_system(char *directory, char c, int level)
{
	level++;
	DIR *dir = opendir(directory);
	if(dir == NULL)
	{
		perror("opendir()");
		return;
	}
	struct dirent *filelist[MAX_FILE_NUMBER] = {NULL};
	struct dirent *dirlist[MAX_FILE_NUMBER] = {NULL};
	sort_dir(filelist, dir, 1, 0);
	sort_dir(dirlist, dir, 1, 1);
	int i;
	for(i = 0; dirlist[i] != NULL; i++)
	{
		if(level == 1)
		{
			printf("%c[%s]\n", c, dirlist[i]->d_name);
			printf("A --- %c\n", c++);
		}
		else
		{
			printf("%c%d[%s]\n", c, i+1, dirlist[i]->d_name);
			printf("%c --- %c%d\n", c, c, i+1);
		}
	}
	for(i = 0; filelist[i] != NULL; i++)
	{
		if(level == 1)
		{
			printf("%c(%s)\n", c, filelist[i]->d_name);
			printf("A --- %c\n", c++);
		}
		else
		{
			printf("%c%d(%s)\n", c, i+1, filelist[i]->d_name);
			printf("%c --- %c%d\n", c, c, i+1);
		}
	}
	char tmp[PATH_MAX];
	strcpy(tmp, directory);
	for(i = 0; dirlist[i] != NULL; i++)
	{
		strcpy(directory, tmp);
		strcat(directory, "/");
		read_system(strcat(directory, dirlist[i]->d_name), i+'B', level);
	}
	closedir(dir);
}