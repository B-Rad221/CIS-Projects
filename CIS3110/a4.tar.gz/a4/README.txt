	
	Usage: ./FSreport <Structure> <Pathname>
		Displays information about the file system and all directories below the path name specified in the second argument. Displays all sub directories in a depth first order and can handle any number of levels. Use -tree as the first argument to display files in alphabetical order along with the owner name, group name, permissions etc. Use -inode as the first argument to display files from smallest inode number to largest inode number along with the size in bytes, number of 512 byte blocks allocated, the size divided by 512 etc.

	tests:
		- ./FSreport -tree /home/socs/CIS3110/a4
		- ./FSreport -tree /home/socs/CIS3110
		- ./FSreport -inode /home/socs/CIS3110/a4
		- ./FSreport -inode /home/socs/CIS3110

	Usage: ./drawDir <Directory In PWD> > <webpage>
		Draws the directory specified on the webpage specified.