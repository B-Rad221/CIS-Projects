#include "a4.h"

int main(int argc, const char *argv[])
{
	if(argc != 3)
	{
		fprintf(stderr, "ERROR: The number of arguments must be 2.\n");
		return(-1);
	}
	int mode;
	if(strcmp("-inode", argv[1]) == 0)
	{
		mode = 0;
		printf("File System Report: Inodes\n\n");
	}
	else if(strcmp("-tree", argv[1]) == 0)
	{
		mode = 1;
		printf("File System Report: Tree Directory Structure\n\n");
	}
	else
	{
		fprintf(stderr, "ERROR: First argument must be either '-inode' or '-tree'.\n");
		return(-1);
	}
	read_dir((char *)argv[2], mode, 0);
	return(0);
}