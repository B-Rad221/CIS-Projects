#include "a3.h"

int main(int argc, const char *argv[])
{
	if(argc != 3)
	{
		fprintf(stderr, "ERROR: The number of arguments must be 2.\n");
		return(-1);
	}
	if(strspn(argv[1], "0123456789") != strlen(argv[1]) || strspn(argv[2], "0123456789") != strlen(argv[2]))
	{
		fprintf(stderr, "ERROR: Arguments must be numbers\n");
		return(-1);
	}
	num_philosophers = atoi(argv[1]);
	long reps = atoi(argv[2]);
	if(num_philosophers <= 2)
	{
		fprintf(stderr, "ERROR: The number of philosophers must be greater than 2.\n");
		return(-1);
	}
	if(reps < 1 || reps > 1000)
	{
		fprintf(stderr, "ERROR: The number of times to eat must be greater than one and less than a thousand.\n");
		return(-1);
	}
	sem_init(&S, 0, num_philosophers-1);
	chops = malloc(sizeof(sem_t) * (num_philosophers+1));
	int i;
	for(i = 0; i < num_philosophers; i++)
	{
		sem_init(&chops[i], 0, 1);
	}
	pthread_t *philosophers = malloc(sizeof(pthread_t) * (num_philosophers+1));
	int rc;
	for(i = 0; i < num_philosophers; i++)
	{
		rc = pthread_create(&philosophers[i], NULL, philosopher, (void *)reps);
		if(rc)
		{
			fprintf(stderr, "ERROR: Return code from pthread_create() is %d\n", rc);
			exit(-1);
		}
	}
	for(i = 0; i < num_philosophers; i++)
	{
		rc = pthread_join(philosophers[i], NULL);
		if(rc)
		{
			fprintf(stderr, "ERROR: Return code from pthread_join() is %d\n", rc);
			exit(-1);
		}	
		sem_destroy(&chops[i]);
	}
	sem_destroy(&chops[num_philosophers]);
	sem_destroy(chops);
	sem_destroy(&S);
	free(chops);
	free(philosophers);
	pthread_exit(NULL);
}