#include "a3.h"


int main(int argc, char const *argv[])
{
	if(argc != 3)
	{
		fprintf(stderr, "ERROR: There must be two arguments: ./holes <filename> <algorithm>\n");
		return(-1);
	}
	FILE *fp = fopen(argv[1], "r");
	if(fp == NULL)
	{
		fprintf(stderr, "ERROR: File does not exist.\n");
		return(-1);
	}
	int algorithm;
	if(strcmp(argv[2], "best") == 0)
	{
		algorithm = 0;
	}
	else if(strcmp(argv[2], "worst") == 0)
	{
		algorithm = 1;
	}
	else if(strcmp(argv[2], "next") == 0)
	{
		algorithm = 2;
	}
	else if(strcmp(argv[2], "first") == 0)
	{
		algorithm = 3;
	}
	else
	{
		fprintf(stderr, "ERROR: Algorithm not recognized: Argument must be best, worst, next, or first.\n");
		return(-1);
	}
	RQ *ready = NULL;
	char input[100];
	while(fgets(input, 100, fp) != NULL)
	{
		int count;
		char **parsed = parse_input(input, &count);
		char id = parsed[0][0];
		int size;
		if(strspn(parsed[1], "0123456789") == strlen(parsed[1]))
		{
			size = atoi(parsed[1]);
		}
		else
		{
			fprintf(stderr, "ERROR: Invalid file format. Size must be an integer\n");
			return(-1);
		}
		enqueue(&ready, id, size, 0, 0);
		free_string_array(parsed, count);
	}
	RQ in_memory[MEMORY_SIZE]; // Contains the processes that are in memory
	int memory[MEMORY_SIZE]; // Memory not in use will have a value of zero, memory in use will have a value other than zero
	int i;
	for(i = 0; i < MEMORY_SIZE; i++)
	{
		memory[i] = 0;
	}
	processes_in_memory = 0;
	int loads = 0;
	int process_sum = 0;
	int hole_sum = 0;
	double usage_sum = 0.0;
	while(!is_empty(&ready))
	{
		in_memory[processes_in_memory] = dequeue(&ready);
		if(algorithm == 0)
		{
			while(!best_fit(&in_memory[processes_in_memory], &memory))
			{
				swap_oldest(&ready, &in_memory, &memory);
			}
		}
		else if(algorithm == 1)
		{
			while(!worst_fit(&in_memory[processes_in_memory], &memory))
			{
				swap_oldest(&ready, &in_memory, &memory);
			}
		}
		else if(algorithm == 2)
		{
			while(!next_fit(&in_memory[processes_in_memory], &memory))
			{
				swap_oldest(&ready, &in_memory, &memory);
			}
		}
		else
		{
			while(!first_fit(&in_memory[processes_in_memory], &memory))
			{
				swap_oldest(&ready, &in_memory, &memory);
			}
		}
		int j = 0;
		for(j = 0; j <= processes_in_memory; j++)
		{
			in_memory[j].age++;
		}
		processes_in_memory++;
		loads++;
		process_sum += processes_in_memory;
		hole_sum += count_holes(memory);
		usage_sum += mem_usage(memory);
		printf("%c loaded, #processes = %d, #holes = %d, %%memusage = %.f, cumulative %%mem = %.f\n", in_memory[processes_in_memory-1].id, processes_in_memory, count_holes(memory), mem_usage(memory), usage_sum/(double)loads);
	}
	printf("Total loads = %d, average # processes = %.2f, average # holes = %.2f, cumulative %%mem = %.f\n", loads, (double)process_sum/(double)loads, (double)hole_sum/(double)loads, usage_sum/(double)loads);
	free_RQ(&ready);
	return(0);
}