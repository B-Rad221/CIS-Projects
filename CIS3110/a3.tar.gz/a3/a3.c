#include "a3.h"


_Bool lock = false;
int num = -1;
void *philosopher(void *value)
{
	num++;
	int number = num;
	long reps = (long)value;
	while(reps > 0)
	{
		printf("Philosopher #%d is thinking\n", number+1);
		// Intializes random number generator
	  	srand(time(0));
	  	sleep((float)rand()/(float)RAND_MAX);
		sem_wait(&S);
		if((number)%2 == 0)
		{
			sem_wait(&chops[number]);
			sem_wait(&chops[(number+1)%(num_philosophers-1)]);
		}
		else
		{
			sem_wait(&chops[(number+1)%(num_philosophers-1)]);
			sem_wait(&chops[number]);
		}
		printf("Philosopher #%d is eating\n", number+1);
		// Intializes random number generator
	  	srand(time(0));
	  	sleep((float)rand()/(float)RAND_MAX);
	  	sem_post(&chops[(number+1)%(num_philosophers-1)]);
	  	sem_post(&chops[number]);
	  	sem_post(&S);
	  	reps--;
	}
	printf("Philosopher #%d is thinking\n", number+1);
	pthread_exit(NULL);
}


char **parse_input(char *input, int *count)
{
	int i, difference;
	char **output;
	int previous = 0;
	int j = 0;
	_Bool word = false;
	*count = 0;
	for(i = 0; i < strlen(input); i++)
	{
		if(input[i] != ' ' && input[i] != '\n' && input[i] != '=')
		{
			word = true;
		}
		if((input[i] == ' ' || input[i] == '\n' || input[i] == '=') && word == true)
		{
			(*count)++;
			word = false;
		}
	}
	word = false;
	output = malloc((*count) * sizeof(char *));
	for(i = 0; i < strlen(input); i++)
	{
		if(word == false && (input[i] != ' ' && input[i] != '\n' && input[i] != '='))
		{
			word = true;
			previous = i;
		}
		if((input[i] == ' ' || input[i] == '\n' || input[i] == '=') && word == true)
		{
			difference = i - previous;
			output[j] = malloc(difference+1);
			strncpy(output[j], input + previous, difference);
			output[j][difference] = '\0';
			j++;
			word = false;
		}
	}
	return(output);
}

void free_string_array(char **array, int count)
{
	int i;
	for(i = 0; i < count; i++)
	{
		free(array[i]);
	}
	free(array);
}

RQ *enqueue(RQ **head, char id, int size, int swaps, int age)
{
	RQ *new_node = malloc(sizeof(RQ));
	if(new_node == NULL)
	{
		fprintf(stderr, "Unable to allocate memory for the structure\n");
		return (NULL);
	}
	new_node->id = id;
	new_node->size = size;
	new_node->swaps = swaps;
	new_node->age = 0;
	new_node->start_position = -1;
	if(*head == NULL)
	{
		*head = new_node;
		new_node->next = NULL;
		return (new_node);
	}
	RQ *tmp = *head;
	while(tmp->next != NULL)
	{
		tmp = tmp->next;
	}
	new_node->next = NULL;
	tmp->next = new_node;
	return (new_node);
}

RQ dequeue(RQ **head)
{
	if(*head == NULL)
	{
		fprintf(stderr, "Queue is empty! Cannot dequeue.\n");
		return(**head);
	}
	RQ *tmp = *head;
	*head = (*head)->next;
	RQ removed;
	removed.id = tmp->id;
	removed.size = tmp->size;
	removed.age = tmp->age;
	removed.swaps = tmp->swaps;
	removed.start_position = tmp->start_position;
	removed.next = NULL;
	free(tmp);
	return(removed);
}

void free_RQ(RQ **head)
{
	while(*head != NULL)
	{
		dequeue(head);
	}
}

_Bool is_empty(RQ **head)
{
	return(*head == NULL);
}

void swap_oldest(RQ **head, RQ (*in_memory)[MEMORY_SIZE], int (*memory)[MEMORY_SIZE])
{
	int i, j;
	int oldest = -1;
	for(i = 0; i < processes_in_memory; i++)
	{
		if((*in_memory)[i].age > oldest)
		{
			oldest = (*in_memory)[i].age;
			j = i;
		}
	}
	(*in_memory)[j].swaps++;
	if((*in_memory)[j].swaps < 3)
	{
		enqueue(head, (*in_memory)[j].id, (*in_memory)[j].size, (*in_memory)[j].swaps, (*in_memory)[j].age);
	}
	free_memory((*in_memory)[j].start_position, (*in_memory)[j].size, memory, j, in_memory);
}

void free_memory(int start, int size, int (*memory)[MEMORY_SIZE], int process, RQ (*in_memory)[MEMORY_SIZE])
{
	int i;
	for(i = start; i < (start+size); i++)
	{
		if((*memory)[i] == 2 && start != 0 && (*memory)[start-1] == 1)
		{
			(*memory)[start-1] = 2;
		}
		else
		{
			(*memory)[i] = 0;
		}
	}
	for(i = process; i < processes_in_memory; i++)
	{
		(*in_memory)[i] = (*in_memory)[i+1];
	}
	processes_in_memory--;
}

int count_holes(int memory[MEMORY_SIZE])
{
	int count = 0;
	int i;
	for(i = 0; i < MEMORY_SIZE; i++)
	{
		if(memory[i] == 0)
		{
			count++;
			while(memory[i] == 0)
			{
				i++;
			}
		}
	}
	return(count);
}

double mem_usage(int memory[MEMORY_SIZE])
{
	int count = 0;
	int i;
	for(i = 0; i < MEMORY_SIZE; i++)
	{
		if(memory[i] != 0)
		{
			count++;
		}
	}
	return(((double)count/(double)MEMORY_SIZE) * 100);
}

int best_fit(RQ *node, int (*memory)[MEMORY_SIZE])
{
	int i;
	int holesizes[MEMORY_SIZE];
	int smallest = MEMORY_SIZE + 1;
	for(i = 0; i < MEMORY_SIZE; i++)
	{
		holesizes[i] = 0;
	}
	for(i = 0; i < MEMORY_SIZE; i++)
	{
		if((*memory)[i] == 0)
		{
			int n = i;
			while((*memory)[i] == 0)
			{
				holesizes[n]++;
				i++;
			}
		}
	}
	int j = -1;
	// find smallest holesize
	for(i = 0; i < MEMORY_SIZE; i++)
	{
		if(holesizes[i] >= node->size && holesizes[i] < smallest)
		{
			smallest = holesizes[i];
			j = i;
		}
	}
	if(j == -1)
	{
		return(0);
	}
	node->start_position = j;
	int end = j + node->size;
	// load node into memory
	while(j < end)
	{
		(*memory)[j] = 1;
		j++;
	}
	return(1);
}

int worst_fit(RQ *node, int (*memory)[MEMORY_SIZE])
{
	int i;
	int holesizes[MEMORY_SIZE];
	int largest = -1;
	for(i = 0; i < MEMORY_SIZE; i++)
	{
		holesizes[i] = 0;
	}
	for(i = 0; i < MEMORY_SIZE; i++)
	{
		if((*memory)[i] == 0)
		{
			int n = i;
			while((*memory)[i] == 0)
			{
				holesizes[n]++;
				i++;
			}
		}
	}
	int j = -1;
	// find largest holesize
	for(i = 0; i < MEMORY_SIZE; i++)
	{
		if(holesizes[i] >= node->size && holesizes[i] > largest)
		{
			largest = holesizes[i];
			j = i;
		}
	}
	if(j == -1)
	{
		return(0);
	}
	node->start_position = j;
	int end = j + node->size;
	// load node into memory
	while(j < end)
	{
		(*memory)[j] = 1;
		j++;
	}
	return(1);
}

int next_fit(RQ *node, int (*memory)[MEMORY_SIZE])
{
	int i;
	int start = 0;
	int holesizes[MEMORY_SIZE];
	for(i = 0; i < MEMORY_SIZE; i++)
	{
		holesizes[i] = 0;
	}
	for(i = 0; i < MEMORY_SIZE; i++)
	{
		if((*memory)[i] == 2)
		{
			start = i;
		}
		if((*memory)[i] == 0)
		{
			int n = i;
			while((*memory)[i] == 0)
			{
				holesizes[n]++;
				i++;
			}
		}
	}
	// find next hole that fits
	i = start;
	if(holesizes[i] < node->size)
	{
		i++;
		i = i % MEMORY_SIZE;
		while(i != start)
		{
			if(holesizes[i] >= node->size)
			{
				break;
			}
			i++;
			i = i % MEMORY_SIZE;
		}
	}
	if(holesizes[i] < node->size)
	{
		return(0);
	}
	node->start_position = i;
	int end = i + node->size;
	int j;
	for(j = 0; j < MEMORY_SIZE; j++)
	{
		if((*memory)[j] == 2)
		{
			(*memory)[j] = 1;
		}
	}
	// load node into memory
	while(i < end-1)
	{
		(*memory)[i] = 1;
		i++;
	}
	(*memory)[i] = 2;
	return(1);
}

int first_fit(RQ *node, int (*memory)[MEMORY_SIZE])
{
	int i;
	int holesizes[MEMORY_SIZE];
	for(i = 0; i < MEMORY_SIZE; i++)
	{
		holesizes[i] = 0;
	}
	for(i = 0; i < MEMORY_SIZE; i++)
	{
		if((*memory)[i] == 0)
		{
			int n = i;
			while((*memory)[i] == 0)
			{
				holesizes[n]++;
				i++;
			}
		}
	}
	// find first hole that fits
	for(i = 0; i < MEMORY_SIZE; i++)
	{
		if(holesizes[i] >= node->size)
		{
			break;
		}
	}
	if(holesizes[i] < node->size)
	{
		return(0);
	}
	node->start_position = i;
	int end = i + node->size;
	// load node into memory
	while(i < end)
	{
		(*memory)[i] = 1;
		i++;
	}
	return(1);
}