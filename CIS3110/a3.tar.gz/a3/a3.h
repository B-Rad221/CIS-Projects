#ifndef A3FUNCTIONS_H
#define A3FUNCTIONS_H
#include <pthread.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include <unistd.h>
#include <stdbool.h>
#include <semaphore.h>
#define MEMORY_SIZE 128
#define MAX_AGE 20

//Dining Philosophers
sem_t S;
sem_t *chops;
int num_philosophers;
void *philosopher(void *value);

//Memory Holes
typedef struct READY_QUEUE
{
	char id; // process id
	int size; // size of process in MB
	int age; // amount of time process has spent in memory
	int start_position; // The offset in MB of the start of the process in memory
	int swaps; // number of times this process has been swapped out
	struct READY_QUEUE *next;
}RQ;

int processes_in_memory;

RQ *enqueue(RQ **head, char id, int size, int swaps, int age);
RQ dequeue(RQ **head);
void free_RQ(RQ **head);
_Bool is_empty(RQ **head);
void free_memory(int start, int size, int (*memory)[MEMORY_SIZE], int process, RQ (*in_memory)[MEMORY_SIZE]);
void swap_oldest(RQ **head, RQ (*in_memory)[MEMORY_SIZE], int (*memory)[MEMORY_SIZE]);
int count_holes(int memory[MEMORY_SIZE]);
double mem_usage(int memory[MEMORY_SIZE]);
int best_fit(RQ *node, int (*memory)[MEMORY_SIZE]);
int worst_fit(RQ *node, int (*memory)[MEMORY_SIZE]);
int next_fit(RQ *node, int (*memory)[MEMORY_SIZE]);
int first_fit(RQ *node, int (*memory)[MEMORY_SIZE]);
char **parse_input(char *input, int *count);
void free_string_array(char **array, int count);

#endif