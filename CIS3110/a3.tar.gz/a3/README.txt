Usage: $./dine [#of philosophers] [#of times to eat]

	Simulates the dining philosophers problem and displays which philosophers are eating and which philosophers are thinking. The number of philosophers at the table is specified by the first argument. The simulation stops when each philosopher has eaten a number of times equal to the number specified in the second argument. These numbers can be any number, no maximum was assumed.

Tests:
	- ./dine 3 2
	- ./dine 5 2
	- ./dine 3 3
	- ./dine 6 4
	- ./dine 30 1

Usage: $./holes [input file name] [algorithm]

	Simulates memory management algorithms and displays stats such as the number of holes and the %memory usage. Processes to manage are loaded from the file specified in the first argument. The algorithm to use is specified in the second argument, and must be "best", "worst", "next", or "first". The size of the memory is specified as a macro in the a3.h file and can be changed as needed (default 128). The memory is represented in the program by an integer array of size MEMORY_SIZE, which uses zeroes to represent free memory/holes and any other number to represent memory that is occupied by a program (generally ones). The next fit algorithm places a 2 at the end of the memory that was allocated last. If there is not enough space for a program, the oldest program in memory is removed from memory and placed at the end of a queue, until there is enough space for the program. Once a program has been removed from memory 3 times, it is not re-queued.

Tests:
	- ./holes holes.txt best
	- ./holes holes.txt worst
	- ./holes holes.txt next
	- ./holes holes.txt first
	- ./holes inputfile.txt best
	- ./holes inputfile.txt worst
	- ./holes inputfile.txt next
	- ./holes inputfile.txt first