#include "simfunctions.h"

int size = 0;
char **parse_input(char *input, int *count)
{
	int i, difference;
	char **output;
	int previous = 0;
	int j = 0;
	_Bool word = false;
	*count = 0;
	for(i = 0; i < strlen(input); i++)
	{
		if(input[i] != ' ' && input[i] != '\n' && input[i] != '=')
		{
			word = true;
		}
		if((input[i] == ' ' || input[i] == '\n' || input[i] == '=') && word == true)
		{
			(*count)++;
			word = false;
		}
	}
	word = false;
	output = malloc((*count) * sizeof(char *));
	for(i = 0; i < strlen(input); i++)
	{
		if(word == false && (input[i] != ' ' && input[i] != '\n' && input[i] != '='))
		{
			word = true;
			previous = i;
		}
		if((input[i] == ' ' || input[i] == '\n' || input[i] == '=') && word == true)
		{
			difference = i - previous;
			output[j] = malloc(difference+1);
			strncpy(output[j], input + previous, difference);
			output[j][difference] = '\0';
			j++;
			word = false;
		}
	}
	return(output);
}

void free_string_array(char **array, int count)
{
	int i;
	for(i = 0; i < count; i++)
	{
		free(array[i]);
	}
	free(array);
}

void attachNode(PQ **node, int PNum, int TNum, int arrival, int direction)
{
	PQ *new_node = malloc(sizeof(PQ));
	if(new_node == NULL)
	{
		fprintf(stderr, "Unable to allocate memory for the node structure\n");
		return;
	}
	new_node->PNumber = PNum;
	new_node->TNumber = TNum;
	new_node->ArrivalTime = arrival;
	new_node->bursts[0].cpuTime = -1;
	new_node->completed_bursts = 0;
	new_node->left = NULL;
	new_node->right = NULL;
	if(direction < 0)
	{
		(*node)->left = new_node;
	}
	else if(direction > 0)
	{
		(*node)->right = new_node;
	}
	else
	{
		*node = new_node;
	}
	last_node = new_node;
	size++;
}

PQ **next(PQ **node, int direction)
{
	if(*node == NULL)
	{
		fprintf(stderr, "Heap is empty!");
		return NULL;
	}
	if(direction < 0)
	{
		return &((*node)->left); // negative direction goes left
	}
	else
	{
		return &((*node)->right); // positive direction goes right
	}
}

PQ *upheap(PQ **root)
{
	PQ **node = root;
	PQ *new = last_node;
	int j = 1;
	while(new != *node)
	{
		char binary[100];
		*binaryToAbits(size, binary) = '\0';
		int i;
		for(i = 1; i < strlen(binary) - j; i++) // Finds the parent node of the inserted node
		{
			if(binary[i] == '0')
			{
				node = next(node, -1);
			}
			else
			{
				node = next(node, 1);
			}
		}		
		if((*node)->ArrivalTime > new->ArrivalTime)
		{
			swap(*node, new);
			new = *node;
			node = root;
			j++;
		}
		else
		{
			return new;
		}
	}
	return new;
}

PQ *insertItem(PQ **root, int PNum, int TNum, int arrival)
{
	PQ **node = root;
	if(*node == NULL)
	{
		attachNode(node, PNum, TNum, arrival, 0);
		return(*node);
	}
	if((*node)->right != NULL && (*node)->left != NULL)
	{
		node = next(node, -1);
		insertItem(node, PNum, TNum, arrival);
	}
	else if((*node)->left != NULL && (*node)->right == NULL)
	{
		attachNode(node, PNum, TNum, arrival, 1);
	}
	else
	{
		attachNode(node, PNum, TNum, arrival, -1);
	}
	return(upheap(root));
}

char *binaryToAbits(unsigned int answer, char *result) 
{
  if(answer>1) {
    result=binaryToAbits(answer>>1,result);
  }
  *result='0'+(answer & 0x01);
  return result+1;
}

PQ *findLastNode(PQ **root)
{
	// Finding the binary representation of the size of the heap shows where the last node is
	char binary[100];
	*binaryToAbits(size, binary) = '\0';
	int i;
	PQ **node = root;
	if(strlen(binary) == 1)
	{
		return (*node);
	}
	// Starting at the second binary digit, if the digit is zero go to the left child, and if it is one, go to the right child
	for(i = 1; i < strlen(binary); i++)
	{
		if(binary[i] == '0')
		{
			node = next(node, -1);
		}
		else
		{
			node = next(node, 1);
		}
	}
	return *node;
}

void detachNode(PQ *node)
{
	if(node == NULL)
	{
		fprintf(stderr, "Heap is empty! Cannot detach.");
		return;
	}
	PQ *tmp = node;
	node->left = NULL;
	node->right = NULL;
	node = NULL;
	size--;
	free(tmp);
}

void swap(PQ *one, PQ *two)
{
	int arrival = one->ArrivalTime;
	int PNum = one->PNumber;
	int TNum = one->TNumber;
	int completed = one->completed_bursts;
	burst tmp[1024];
	int i;
	for(i = 0; i < 1024; i++)
	{
		tmp[i].cpuTime = one->bursts[i].cpuTime;
		tmp[i].ioTime = one->bursts[i].ioTime;
	}
	one->ArrivalTime = two->ArrivalTime;
	one->PNumber = two->PNumber;
	one->TNumber = two->TNumber;
	one->completed_bursts = two->completed_bursts;
	for(i = 0; i < 1024; i++)
	{
		one->bursts[i].cpuTime = two->bursts[i].cpuTime;
		one->bursts[i].ioTime = two->bursts[i].ioTime;
	}
	for(i = 0; i < 1024; i++)
	{
		two->bursts[i].cpuTime = tmp[i].cpuTime;
		two->bursts[i].ioTime = tmp[i].ioTime;
	}
	two->PNumber = PNum;
	two->TNumber = TNum;
	two->ArrivalTime = arrival;
	two->completed_bursts = completed;
}

void downheap(PQ **root)
{
	PQ **node = root;
	while((*node)->left != NULL && (*node)->right != NULL) // Not a leaf node
	{
		if((*node)->left->ArrivalTime < (*node)->ArrivalTime && (*node)->left->ArrivalTime < (*node)->right->ArrivalTime && (*node)->left != NULL) // left child arrival time is smaller than the node's arrival time and the right child's arrival time
		{
			swap(*node, (*node)->left); // swap data of the node and its left child
			node = next(node, -1); // move to the left child
		}
		else if((*node)->right->ArrivalTime < (*node)->ArrivalTime && (*node)->right != NULL) // right child arrival time is smaller than the node's arrival time
		{
			swap(*node, (*node)->right); // swap data of the node and its right child
			node = next(node, 1); // move to the right child
		}
		else
		{
			return;
		}
	}
}

void removeMin(PQ **root)
{
	if(*root == NULL)
	{
		fprintf(stderr, "Queue is empty! Cannot remove.\n");
		return; //NULL;
	}
	swap(*root, last_node);
	detachNode(last_node);
	last_node = findLastNode(root);
	downheap(root);
}

PQ *minElement(PQ **root)
{
	return(*root);
}

_Bool isEmpty()
{
	if(size == 0)
	{
		return true;
	}
	return false;
}

int Size()
{
	return size;
}

void free_PQ(PQ **root)
{
	PQ **node = root;
	while(*node != NULL && !isEmpty())
	{
		if((*node)->right != NULL) // if right node exists
		{
			node = next(node, 1);
		}
		else if((*node)->left != NULL) // if right node doesn't exist but left node does
		{
			node = next(node, -1);
		}
		else // left and right branches are NULL. This is a leaf node
		{
			detachNode(*node);
			// reset node pointer to root
			node = root;
		}
	}
}