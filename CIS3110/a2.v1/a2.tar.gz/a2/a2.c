#include "simfunctions.h"

int main(int argc, char const *argv[])
{
	int i = 0;
	int processes = 0;
	int TSwitch = 0;
	int PSwitch = 0;
	int PNumber = 0;
	int ThreadsLeft = 0;
	int BurstsLeft = 0;
	int TNumber = 0;
	int ArrivalTime = 0;
	int BNumber = 0;
	_Bool detailed = false;
	_Bool verbose = false;
	_Bool RR = false;
	int quantum;
	for(i = 0; i < argc; i++)
	{
		if(strcmp(argv[i], "-d") == 0)
		{
			detailed = true;
		}
		if(strcmp(argv[i], "-v") == 0)
		{
			verbose = true;
		}
		if(strcmp(argv[i], "-r") == 0)
		{
			RR = true;
			quantum = atoi(argv[i+1]);
		}
	}
	i = 0;
	PQ *priority_queue = NULL;
	PQ *inserted = NULL;
	stats Threads[50][50];
	char input[100];
	while(fgets(input, 100, stdin) != NULL)
	{
		//printf("%s", input);
		if(strspn(input, "0123456789 \n") != strlen(input))
		{
			fprintf(stderr, "ERROR: Input must only contain numbers.\n");
			return(-1);
		}
		int count;
		char **parsed = parse_input(input, &count);
		if(i == 0)
		{
			if(count != 3)
			{
				fprintf(stderr, "Invalid file format\n");
				return(-1);
			}
			processes = atoi(parsed[0]);
			TSwitch = atoi(parsed[1]);
			PSwitch = atoi(parsed[2]);
		}
		else
		{
			if(processes > 0 && ThreadsLeft == 0 && BurstsLeft == 0)
			{
				if(count != 2)
				{
					fprintf(stderr, "Invalid file format\n");
					return(-1);
				}
				PNumber = atoi(parsed[0]);
				ThreadsLeft = atoi(parsed[1]);
			}
			else if(ThreadsLeft > 0 && BurstsLeft == 0)
			{
				if(count != 3)
				{
					fprintf(stderr, "Invalid file format\n");
					return(-1);
				}
				TNumber = atoi(parsed[0]);
				ArrivalTime = atoi(parsed[1]);
				BurstsLeft = atoi(parsed[2]);
				inserted = insertItem(&priority_queue, PNumber, TNumber, ArrivalTime);
				Threads[PNumber - 1][TNumber - 1].ArrivalTime = ArrivalTime;
				Threads[PNumber - 1][TNumber].ArrivalTime = -1;
				ThreadsLeft--;
			}
			else if(BurstsLeft > 0)
			{
				if(count == 3)
				{
					BNumber = atoi(parsed[0]);
					inserted->bursts[BNumber - 1].cpuTime = atoi(parsed[1]);
					inserted->bursts[BNumber - 1].ioTime = atoi(parsed[2]);
					Threads[PNumber - 1][TNumber - 1].TotalCPUTime += atoi(parsed[1]);
					Threads[PNumber - 1][TNumber - 1].TotalIOTime += atoi(parsed[2]);
				}
				else if(count == 2)
				{
					BNumber = atoi(parsed[0]);
					inserted->bursts[BNumber - 1].cpuTime = atoi(parsed[1]);
					inserted->bursts[BNumber - 1].ioTime = 0;
					inserted->bursts[BNumber].cpuTime = -1; // Signals the last burst of the thread
					Threads[PNumber - 1][TNumber - 1].TotalCPUTime += atoi(parsed[1]);
				}
				else
				{
					fprintf(stderr, "Invalid file format\n");
					return(-1);
				}
				BurstsLeft--;
			}
		}
		free_string_array(parsed, count);
		i++;
	}
	int time = 0;
	int idleTime = 0;
	int processTurnaroundTime[50] = {-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
	int processArrival[50];
	while(!isEmpty())
	{
		PQ *current = minElement(&priority_queue);
		if(verbose)
		{
			for(i = 0; i < processes; i++)
			{
				int j;
				for(j = 0; Threads[i][j].ArrivalTime != -1; j++)
				{
					if(Threads[i][j].unblockTime < (time + idleTime) && Threads[i][j].unblockTime != 0)
					{
						printf("At time %d: Thread %d of Process %d moves from blocked to ready\n", Threads[i][j].unblockTime, j+1, i+1);
						Threads[i][j].unblockTime = 0;
					}
				}
			}
			if(current->completed_bursts == 0)
			{
				printf("At time %d: Thread %d of Process %d moves from new to ready\n", (time + idleTime), current->TNumber, current->PNumber);
			}
			printf("At time %d: Thread %d of Process %d moves from ready to running\n", (time + idleTime), current->TNumber, current->PNumber);
		}
		PNumber = current->PNumber;
		TNumber = current->TNumber;
		if(processTurnaroundTime[PNumber - 1] == -1)
		{
			processTurnaroundTime[PNumber - 1] = 0;
			processArrival[PNumber - 1] = current->ArrivalTime;
		}
		if(current->ArrivalTime > (time + idleTime))
		{
			idleTime += (current->ArrivalTime - (time+idleTime));
			time = current->ArrivalTime;
		}
		if(RR)
		{
			if(current->bursts[current->completed_bursts].cpuTime > quantum)
			{
				time += quantum;
				current->bursts[current->completed_bursts].cpuTime -= quantum;
				printf("At time %d: Thread %d of Process %d moves from running to blocked\n", (time + idleTime), current->TNumber, current->PNumber);
				Threads[PNumber - 1][TNumber - 1].unblockTime = time + current->ArrivalTime;
			}
			else
			{
				time += current->bursts[current->completed_bursts].cpuTime;
				current->completed_bursts++;
			}
		}
		else
		{
			time += current->bursts[current->completed_bursts].cpuTime;
			current->completed_bursts++;
		}
		if(current->bursts[current->completed_bursts].cpuTime == -1)
		{
			printf("At time %d: Thread %d of Process %d moves from running to terminated\n", (time + idleTime), current->TNumber, current->PNumber);
			Threads[PNumber - 1][TNumber - 1].FinishTime = (time + idleTime);
			Threads[PNumber - 1][TNumber - 1].TurnaroundTime = Threads[PNumber - 1][TNumber - 1].FinishTime - Threads[PNumber - 1][TNumber - 1].ArrivalTime;
			removeMin(&priority_queue);
			if((time + idleTime) > processTurnaroundTime[PNumber - 1])
			{
				processTurnaroundTime[PNumber - 1] += (time + idleTime) - processTurnaroundTime[PNumber - 1];
			}
		}
		else
		{
			current->ArrivalTime = time + current->bursts[current->completed_bursts].ioTime;
			if(verbose)
			{
				if(current->bursts[current->completed_bursts].ioTime > 0)
				{
					printf("At time %d: Thread %d of Process %d moves from running to blocked\n", (time + idleTime), current->TNumber, current->PNumber);
					Threads[PNumber - 1][TNumber - 1].unblockTime = time + current->ArrivalTime;
				}
				else
				{
					printf("At time %d: Thread %d of Process %d moves from running to ready\n", (time + idleTime), current->TNumber, current->PNumber);
				}
			}
			downheap(&current);
		}
		if(PNumber != current->PNumber && !isEmpty())
		{
			idleTime += PSwitch;
		}
		else if(TNumber != current->TNumber && !isEmpty())
		{
			idleTime += TSwitch;
		}
	}
	int totalTime = time + idleTime;
	printf("Total Time Required: %d\n", totalTime);
	double averageTurnaround;
	for(i = 0; processTurnaroundTime[i] != -1; i++)
	{
		averageTurnaround += (processTurnaroundTime[i] - processArrival[i]);
	}
	printf("Average Turnaround Time: %.1f\n", averageTurnaround/(double)i);
	printf("CPU Utilization: %.1f %%\n", ((double)time/(double)totalTime)*100);
	if(detailed)
	{
		for(i = 0; i < processes; i++)
		{
			int j;
			for(j = 0; Threads[i][j].ArrivalTime != -1; j++)
			{
				printf("Thread %d of Process %d\n", j+1, i+1);
				printf("Arrival Time: %d\n", Threads[i][j].ArrivalTime);
				printf("Service Time: %d, I/O Time: %d, Turnaround Time: %d, Finish Time: %d\n", Threads[i][j].TotalCPUTime, Threads[i][j].TotalIOTime, Threads[i][j].TurnaroundTime, Threads[i][j].FinishTime);
			}
		}
	}
	free_PQ(&priority_queue);
	return(0);
}