
Usage: $./simcpu [-d] [-v] [-r quantum] < inputfile

	Simulates FCFS and RR cpu scheduling algorithms and displays information about their efficiency. Use the -d flag to show detailed information about each thread. Use the -v flag to display when the threads change states. Use the -r flag followed by a space and a number to use round robin scheduling. It is assumed that a number will always follow the -r flag. The flags can be entered in any order. Sometimes the program will try to run a thread that doesn't exist. If this happens, rerunning the program usually fixes the problem.

Tests:
Each of the following tests were done with an input file that contained 2 processes each with 2 threads.
	- No flags 
	- -d flag
	- -v flag
	- both -d and -v flags
	- -r with quantum 10
	- -r with quantum 50
	- -d, -v, and -r with quantum 50