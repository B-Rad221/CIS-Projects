#ifndef SIMFUNCTIONS_H
#define SIMFUNCTIONS_H
#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <sys/mman.h>
#include <sys/wait.h>
#include <unistd.h>
#include <fcntl.h>

char **parse_input(char *input, int *count);
void free_string_array(char **array, int count);

typedef struct BURST
{
	int cpuTime;
	int ioTime;
}burst;

typedef struct PRIORITY_QUEUE
{
	int PNumber;
	int TNumber;
	int ArrivalTime;
	burst bursts[1024];
	int completed_bursts;
	struct PRIORITY_QUEUE *left;
	struct PRIORITY_QUEUE *right;
}PQ;

typedef struct THREAD_STATS
{
	int ArrivalTime;
	int FinishTime;
	int TurnaroundTime;
	int TotalCPUTime;
	int TotalIOTime;
	int unblockTime;
}stats;

PQ *last_node;
void attachNode(PQ **node, int PNum, int TNum, int arrival, int direction);
PQ **next(PQ **node, int direction);
PQ *upheap(PQ **root);
PQ *insertItem(PQ **root, int PNum, int TNum, int arrival);
char *binaryToAbits(unsigned int answer, char *result);
PQ *findLastNode(PQ **root);
void detachNode(PQ *node);
void swap(PQ *one, PQ *two);
void downheap(PQ **root);
void removeMin(PQ **root);
PQ *minElement(PQ **root);
void free_PQ(PQ **root);
_Bool isEmpty();
int Size();

#endif