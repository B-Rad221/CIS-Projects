#ifndef FUNCTIONS_H
#define FUNCTIONS_H
#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <sys/mman.h>
#include <sys/wait.h>
#include <unistd.h>
#include <fcntl.h>

typedef struct background_process
{
	int id;
	pid_t pid;
	char *name;
	struct background_process *next;
}BP;

void sigquit(int signo);
char **parse_input(char *input, int *count);
void free_string_array(char **array, int count);
_Bool is_valid_program(char **name);
void push(BP **list_ptr, char *src, unsigned int width, int id, pid_t pid);
BP **next(BP **list_ptr);
int isEmpty(BP **list_ptr);
void pop(BP **list_ptr);
void freeList(BP **list_ptr);
void execute_pipe(char **parameters, char **pipe_parameters, int *status);

#endif