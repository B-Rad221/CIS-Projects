#include"functions.h"


#define MAX_INPUT 1024



int main(int argc, char const *argv[])
{
	struct sigaction action;
	action.sa_flags = 0;
	sigemptyset(&action.sa_mask);
	action.sa_handler = sigquit;
	if (sigaction(SIGQUIT, &action, NULL) < 0) 
	{
        perror("sigaction()");
        exit(1);
    }
    // open profile for reading
    FILE *profile = fopen(".CIS3110_profile", "r");
    // if the profile doesn't exist, create a new one with defaults
    if(profile == NULL)
    {
    	profile = fopen(".CIS3110_profile", "w+");
    	fprintf(profile, "export $PATH=/bin\n");
    	fprintf(profile, "export $HISTFILE=.CIS3110_history\n");
    	fprintf(profile, "export $HOME=/home/socs/CIS3110/a1\n");
    }
    char profile_input[MAX_INPUT];
    while(fgets(profile_input, MAX_INPUT, profile))
    {
    	if(profile_input[0] != '\n' && profile_input[0] != '/' && profile_input[1] != '/') // remove empty lines & comment functionality
    	{
    		int size;
    		char **parsed_input = parse_input(profile_input, &size);
    		if(strcmp(parsed_input[0], "export") == 0)
    		{
    			if(setenv(parsed_input[1], parsed_input[2], 1) < 0)
    			{
    				perror("setenv");
    			}
    		}
    		free_string_array(parsed_input, size);
    	}
    }
    fclose(profile);
    _Bool quit = false;
    int status;
    FILE *fout = NULL;
    FILE *fin = NULL;
    int copy_out, out, copy_in, in;
    copy_out = dup(STDOUT_FILENO);
    copy_in = dup(STDIN_FILENO);
    BP *background_processes = NULL;
    int b_id = 1;
    pid_t pid, returnpid;
    FILE *HISTORY = fopen(getenv("$HISTFILE"), "a+");
    int history_length = 0;
    // Find the length of the history file if it already exists
    char load_history[MAX_INPUT];
    fseek(HISTORY, 0, SEEK_SET);
    while(fgets(load_history, MAX_INPUT, HISTORY))
    {
    	history_length++;
    }
    fseek(HISTORY, 0, SEEK_END);
	while(quit == false)
	{
		char **parameters;
    	int count;
    	dup2(copy_out, STDOUT_FILENO);
    	dup2(copy_in, STDIN_FILENO);
		printf("%s> ", getenv("PWD"));
		char input[MAX_INPUT];
		fgets(input, MAX_INPUT, stdin);
		parameters = parse_input(input, &count);
		char tmp[MAX_INPUT] = "";
		 _Bool piped = false;
		char **pipe_parameters;
		char pipe_in[MAX_INPUT] = "";
		int pcount;
		if(strcmp(parameters[0], "exit") == 0)
		{
			quit = true;
		}
		else if(is_valid_program(&parameters[0]))
		{
			// add to history file
			history_length++;
			fprintf(HISTORY, " %d  %s", history_length, input);
			// parse special cases
			_Bool background = false;
			int i;
			for(i = 0; i < count; i++)
			{
				if(strcmp(parameters[i], ">") == 0)
				{
					i++;
					fout = fopen(parameters[i], "w+");
					out = fileno(fout);
					dup2(out, STDOUT_FILENO);
				}
				else if(strcmp(parameters[i], "<") == 0)
				{
					i++;
					fin = fopen(parameters[i], "r");
					in = fileno(fin);
					dup2(in, STDIN_FILENO);
				}
				else if(strcmp(parameters[i], "&") == 0)
				{
					background = true;
				}
				else if(strcmp(parameters[i], "|") == 0)
				{
					int j;
					for(j = i + 1; j < count; j++)
					{
						strcat(pipe_in, parameters[j]);
						strcat(pipe_in, " ");
						parameters[j] = NULL;
					}
					pipe_parameters = parse_input(pipe_in, &pcount);
					pipe_parameters[pcount] = NULL;
					piped = true;
					i = count;
				}
				else if(strcmp(parameters[i], "$PATH") == 0)
				{
					strcat(tmp, getenv("$PATH"));
					strcat(tmp, " ");
				}
				else if(strcmp(parameters[i], "$HISTFILE") == 0)
				{
					strcat(tmp, getenv("$HISTFILE"));
					strcat(tmp, " ");
				}
				else if(strcmp(parameters[i], "$HOME") == 0)
				{
					strcat(tmp, getenv("$HOME"));
					strcat(tmp, " ");
				}
				else
				{
					strcat(tmp, parameters[i]);
					strcat(tmp, " ");
				}
			}
			free_string_array(parameters, count);
			parameters = parse_input(tmp, &count);
			parameters[count] = NULL;
			// check to see if any background processes have finished
			BP **node = &background_processes;
			while(!isEmpty(node))
			{
				returnpid = waitpid((*node)->pid, &status, WNOHANG);
				if(returnpid == -1)
    			{
    				//error
    				perror("Background Process");
    			}
    			else if(returnpid == (*node)->pid)
    			{
    				if(WIFEXITED(status))
    				{
    					printf("[%d]+  Done             %s\n", (*node)->id, (*node)->name);
    					pop(node);
    				}
    			}
    			else
    			{
    				node = next(node);
    			}
			}
			if(!piped)
			{
				if ((pid = fork()) < 0) 
   	 			{
   	    			perror("fork");
   	     			exit(1);
   	 			}
    			if(pid == 0)
    			{
    				//Run program
    				status = execv(parameters[0], parameters);
    				fprintf(stderr, "-myShell: %s", parameters[0]);
    				perror(": ");
    				exit(status);
    			}
    			else if(!background)
    			{
    				waitpid(pid, &status, 0);
    			}
    			else
    			{
    				waitpid(pid, &status, WNOHANG);
    			}
    			if(background)
    			{
    				push(&background_processes, input, strlen(input), b_id, pid);
    				fprintf(fdopen(copy_out, "w") ,"[%d] %d\n", b_id++, getpid());
    			}
			}
			else // piped
			{
				if(is_valid_program(&pipe_parameters[0]))
				{
					strcpy(tmp, "");
					for(i = 0; i < pcount; i++)
					{
						if(strcmp(pipe_parameters[i], ">") == 0)
						{
							i++;
							fout = fopen(pipe_parameters[i], "w+");
							out = fileno(fout);
							dup2(out, STDOUT_FILENO);
						}
						else if(strcmp(pipe_parameters[i], "<") == 0)
						{
							i++;
							fin = fopen(pipe_parameters[i], "r");
							in = fileno(fin);
							dup2(in, STDIN_FILENO);
						}
						else if(strcmp(pipe_parameters[i], "&") == 0)
						{
							background = true;
						}
						else
						{
							strcat(tmp, pipe_parameters[i]);
							strcat(tmp, " ");
						}
					}
					free_string_array(pipe_parameters, count);
					pipe_parameters = parse_input(tmp, &count);
					pipe_parameters[count] = NULL;
					pid_t id = fork();
					if(id < 0)
					{
						perror("fork()");
						exit(1);
					}
					if(id == 0)
					{
						execute_pipe(parameters, pipe_parameters, &status);
					}
					else
					{
						waitpid(id, &status, 0);
					}
				}
				else
				{
					fprintf(stderr, "-myShell: %s: Command not found.\n", pipe_parameters[0]);
				}
			}
		}
		else if(strcmp(parameters[0], "history") == 0)
		{
			if(count == 1)
			{
				char output[MAX_INPUT];
				fseek(HISTORY, 0, SEEK_SET);
				while(fgets(output, MAX_INPUT, HISTORY))
				{
					printf("%s", output);
				}
			}
			else
			{
				if(strcmp(parameters[1], "-c") == 0)
				{
					// By reopening the file in w+ mode, the file gets erased
					HISTORY = freopen(getenv("$HISTFILE"), "w+", HISTORY);
					fseek(HISTORY, 0, SEEK_SET);
					history_length = 0;
				}
				else if(atoi(parameters[1]) > 0)
				{
					char output[MAX_INPUT];
					int size = 0;
					fseek(HISTORY, 0, SEEK_SET);
					while(fgets(output, MAX_INPUT, HISTORY))
					{
						size++;
					}
					fseek(HISTORY, 0, SEEK_SET);
					int i = 0;
					while(fgets(output, MAX_INPUT, HISTORY))
					{
						if((size - i) <= atoi(parameters[1]))
						{
							printf("%s", output);
						}
						i++;
					}
				}
			}
			history_length++;
			fprintf(HISTORY, " %d  %s", history_length, input);
		}
		else if(strcmp(parameters[0], "cd") == 0)
		{
			char s[100];
			if(strcmp(parameters[1], "..") == 0)
			{
				strcpy(parameters[1], getenv("PWD"));
				int i;
				for(i = strlen(parameters[1]); i > 0 ; i--)
				{
					if(parameters[1][i] == '/')
					{
						parameters[1][i] = '\0';
						i = 0;
					}
				}
				strcpy(s, parameters[1]);
			}
			else if(strcmp(parameters[1], "~") == 0) // Assuming that if the tilda is entered, it is entered by itself
			{
				strcpy(parameters[1], getenv("$HOME"));
				strcpy(s, getenv("$HOME"));
			}
			else if(parameters[1][0] == '/')
			{
				strcpy(s, getenv("$HOME"));
				strcat(s, parameters[1]);
			}
			else
			{
				strcpy(s, getenv("PWD"));
				strcat(s, "/");
				strcat(s, parameters[1]);
			}
			if(chdir(parameters[1]) != 0)
			{
				perror("cd failed");
			}
			else
			{
				setenv("PWD", s, 1);
			}
		}
		else
		{
			fprintf(stderr, "-myShell: %s: Command not found.\n", parameters[0]);
		}
    	free_string_array(parameters, count);
	}
	fclose(HISTORY);
  	sigaction(SIGQUIT, &action, NULL);
  	kill(0, SIGQUIT);
  	freeList(&background_processes);
	return 0;
}