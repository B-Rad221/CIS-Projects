#include"functions.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>


void sigquit(int signo) 
{
	printf("Signal %d recieved. Process terminating.\n", signo);
    exit(0);
}

char **parse_input(char *input, int *count)
{
	int i, difference;
	char **output;
	int previous = 0;
	int j = 0;
	_Bool word = false;
	*count = 0;
	for(i = 0; i < strlen(input); i++)
	{
		if(input[i] != ' ' && input[i] != '\n' && input[i] != '=')
		{
			word = true;
		}
		if((input[i] == ' ' || input[i] == '\n' || input[i] == '=') && word == true)
		{
			(*count)++;
			word = false;
		}
	}
	word = false;
	output = malloc((*count) * sizeof(char *));
	for(i = 0; i < strlen(input); i++)
	{
		if(word == false && (input[i] != ' ' && input[i] != '\n' && input[i] != '='))
		{
			word = true;
			previous = i;
		}
		if((input[i] == ' ' || input[i] == '\n' || input[i] == '=') && word == true)
		{
			difference = i - previous;
			output[j] = malloc(difference+1);
			strncpy(output[j], input + previous, difference);
			output[j][difference] = '\0';
			j++;
			word = false;
		}
	}
	return(output);
}

void free_string_array(char **array, int count)
{
	int i;
	for(i = 0; i < count; i++)
	{
		free(array[i]);
	}
	free(array);
}

_Bool is_valid_program(char **name)
{
	char prefix[3];
	prefix[0] = (*name)[0];
	prefix[1] = (*name)[1];
	prefix[2] = '\0';
	if(strcmp("./", prefix) == 0)
	{
		return(1);
	}
	char *programs[25] = {"ls", "ps", "more", "chmod", "chown", "wc", "sort", "echo", "pwd", NULL};
	int i;
	for(i = 0; programs[i] != NULL; i++)
	{
		if(strcmp(programs[i], *name) == 0)
		{
			// Assuming the path is no longer than 200 characters
			char s[200];
			strcpy(s, getenv("$PATH"));
			strcat(s, "/");
			strcat(s, *name);
			*name = realloc(*name, 200);
			strcpy(*name, s);
			return(1);
		}
	}
	return(0);
}

// Linked list functions
void push(BP **list_ptr, char *src, unsigned int width, int id, pid_t pid)
{
	BP *new_node = malloc(sizeof(BP));
	if(new_node == NULL)
	{
		fprintf(stderr, "Unable to allocate memory for the node structure\n");
		return;
	}
	new_node->name = malloc(width);
	new_node->id = id;
	new_node->pid = pid;
	// copy width bytes of data from source to new_node->data
	memcpy(new_node->name, src, width);
	new_node->next = *list_ptr; // copy address of *list_ptr (head pointer) to the new node
	*list_ptr = new_node; // head pointer now points at the new node
}

BP **next(BP **list_ptr)
{
	BP *node = *list_ptr;
	if(node == NULL)
	{
		fprintf(stderr, "List is empty!");
		return NULL;
	}
	// return next pointer of *list_ptr
	return &node->next;
}
int isEmpty(BP **list_ptr)
{
	if(*list_ptr == NULL)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}

void pop(BP **list_ptr)
{
	if(*list_ptr == NULL)
	{
		fprintf(stderr, "List is empty! Cannot pop.\n");
		return;
	}
	// Move *list_ptr to next, while keeping the address for the head of the list in a temporary pointer
	BP *tmp = *list_ptr;
	*list_ptr = (*list_ptr)->next;
	// Free first node of list
	free(tmp->name);
	free(tmp);
}

void freeList(BP **list_ptr)
{
	// While the list is not empty, pop items off of the list
	while(!isEmpty(list_ptr))
	{
		pop(list_ptr);
	}
}

void deleteItem(BP **list_ptr, int index)
{
	BP **node = list_ptr;
	int i;
	for(i = 0; i < index; i++)
	{
		node = next(node);
	}
	pop(node);
}

void execute_pipe(char **parameters, char **pipe_parameters, int *status)
{
	int p[2];
	if(pipe(p) < 0)
	{
		perror("pipe");
		exit(1);
	}
	pid_t id = fork();
	if(id < 0)
	{
		perror("fork()");
		exit(1);
	}
	if(id == 0)
	{
		dup2(p[0], STDIN_FILENO);
		close(p[0]);
		close(p[1]);
		*status = execv(pipe_parameters[0], pipe_parameters);
		perror("execv");
		exit(0);
	}
	else
	{
		dup2(p[1], STDOUT_FILENO);
		close(p[1]);
		close(p[0]);
		*status = execv(parameters[0], parameters);
		perror("execv");
		exit(0);
	}
}