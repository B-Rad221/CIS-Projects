
Usage: ./myShell

	Executes shell commands and programs through the use of execv(), fork() and waitpid() functions. Using '>' will redirect stdout to the subsequently named file. Using '<' will redirect stdin to the subsequently named file. A '|' will pipe the input of one command to the next command's input. A '&' will make the process run in the background and will notify upon giving a command if the background process is finished. It was assumed that there wouldn't be two of the same symbol in any given command. A history file keeps track of the commands that are entered. The built-in history command can be used to display the history. "history -c" can be used to clear the history file. Running history n, where n is a whole number, will display the last n commands entered. The built-in cd command can be used to change the current working directory. cd .. takes you to the previous directory. cd ~ takes you to the home directory. It is assumed that both of these options are entered by themselves. cd subdir1/subdir2 will take you directly to subdir2.

Tests:
	- Shell command/program on its own
	- Shell command/program with flags
	- Shell command/program with redirected stdout
	- Shell command/program with redirected stdin
	- Shell command/program with redirected stdout and flags
	- Shell command/program with redirected stdin and flags
	- Shell command/program run in the background
	- Shell command/program with flags run in the background
	- Multiple shell commands/programs with flags run in the background
	- Shell command/program piped to another shell command/program
	- Shell command/program redirected and then piped to another shell command/program
	- Shell command/program with flags piped to another shell command/program
	- Shell command/program with flags redirected and then piped to another shell command/program
	- history
	- history -c
	- history n, where n is a whole number
	- cd subdir
	- cd ..
	- cd ~
	- cd subdir1/subdir2