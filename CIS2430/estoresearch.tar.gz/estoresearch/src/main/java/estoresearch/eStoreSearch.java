package estoresearch;
import java.util.*;
import java.io.*;

public class eStoreSearch 
{
		private ArrayList<Product> products = new ArrayList<Product>();
		private HashMap<String, ArrayList<Integer>> hashIndex = new HashMap<String, ArrayList<Integer>>();
		public static void main(String[] args) 
		{
			boolean quit = false;
			eStoreSearch eStore = new eStoreSearch();
			int productIndex = 0;
			if(!args[0].isEmpty()) // If the first command line argument isn't empty, load the file specified
			{
				try
				{
					File f = new File(args[0]);
					Scanner scanner = new Scanner(f);
					int productId = 0;
					String description = "";
					double price = 0;
					int year = 0;
					String maker_author = "";
					String publisher = "";
					while(scanner.hasNextLine())
					{
						String[] data = scanner.nextLine().split(" = ");
						if(data[0].equals("Id"))
						{
							try
							{
								productId = Integer.parseInt(data[1]);
							}
							catch(Exception ex)
							{
								System.out.println("Invalid data. Id must be of type Integer");
							}
							
						}
						else if(data[0].equals("Description"))
						{
							if(data.length == 2)
							{
								description = data[1];
							}
							
						}
						else if(data[0].equals("Price"))
						{
							if(data.length == 2)
							{
								try
								{
									price = Double.parseDouble(data[1]);
								}
								catch(Exception ex)
								{
									System.out.println("Invalid data. Price must be of type Double");
								}
							}
							
						}
						else if(data[0].equals("Year"))
						{
							try
							{
								year = Integer.parseInt(data[1]);
							}
							catch(Exception ex)
							{
								System.out.println("Invalid data. Year must be of type Integer");
							}
							
						}
						else if(data[0].equals("Author"))
						{
							if(data.length == 2)
							{
								maker_author = data[1];
							}
						}
						else if(data[0].equals("Publisher"))
						{
							if(data.length == 2)
							{
								publisher = data[1];
							}
							
						}
						else if(data[0].equals("Maker"))
						{
							if(data.length == 2)
							{
								maker_author = data[1];
							}
							
						}
						else
						{
							// If there is an empty line, add the product to the ArrayList and reset the variables
							if(description.isEmpty())
							{
								System.out.println("Description not included in file. Product not added.");
							}
							else if(publisher.isEmpty() && !maker_author.isEmpty()) // Product is an electronic
							{
								eStore.addProduct(productId, description, price, year, maker_author);
							}
							else if(!publisher.isEmpty() && !maker_author.isEmpty()) // Product is a book
							{
								eStore.addProduct(productId, description, price, year, maker_author, publisher);
							}
							else
							{
								eStore.addProduct(productId, description, price, year);
							}
							// Add values to our hash map if the description isn't empty
							if(!description.isEmpty())
							{
								eStore.addHash(productIndex, description);
								productIndex++;
							}
							productId = 0;
							description = "";
							price = 0;
							year = 0;
							maker_author = "";
							publisher = "";
						}
					}
				}
				catch(Exception e)
				{
					System.out.println("Unable to load the specified file.");
				}
			}
			Scanner keyboard = new Scanner(System.in);
			while(quit == false)
			{
				System.out.println("\nWelcome to eStoreSearch.\nPlease enter the command you wish to run. (add, search, quit)\n");
				String answer = keyboard.nextLine();
				if(answer.equalsIgnoreCase("add") || answer.equalsIgnoreCase("a"))
				{
					boolean added = false;
					while(added == false)
					{
						System.out.println("What type of item would you like to add? (book, electronic)");
						String type = keyboard.nextLine();
						if(type.equalsIgnoreCase("book") || type.equalsIgnoreCase("b"))
						{
							boolean identified = false;
							while(identified == false)
							{
								System.out.println("Please enter the product ID:");
								if(keyboard.hasNextInt())
								{
									int id = keyboard.nextInt();
									identified = true;
									keyboard.nextLine();
									boolean described = false;
									String desc = "";
									while(described == false)
									{
										System.out.println("Please enter the description:");
										desc = keyboard.nextLine();
										if(!desc.isEmpty())
										{
											described = true;
										}
										else
										{
											System.out.println("Please enter a valid description.");
										}
									}
									System.out.println("Please enter the price (optional):");
									double price = 0.0;
									String price_line = keyboard.nextLine();
									if(!price_line.isEmpty())
									{
										try
										{
											price = Double.parseDouble(price_line);
										}
										catch(NumberFormatException e)
										{
											System.out.println("There was an exception. You entered an invalid data type.");
										}
									}
									boolean y = false;
									int yr = 0;
									while(y == false)
									{
										System.out.println("Please enter the year:");
										if(keyboard.hasNextInt())
										{
											yr = keyboard.nextInt();
											keyboard.nextLine();
											y = true;
										}
										else
										{
											System.out.println("Please enter a valid year.");
										}
									}
									System.out.println("Please enter the author (optional):");
									String auth = keyboard.nextLine();
									System.out.println("Please enter the publisher (optional):");
									String publ = keyboard.nextLine();
									eStore.addProduct(id, desc, price, yr, auth, publ);
									eStore.addHash(productIndex, desc);
									productIndex++;
									added = true;
								}	
								else
								{
									System.out.println("Invalid input.\n");
									keyboard.nextLine();
								}
							}
						}
						else if(type.equalsIgnoreCase("electronic") || type.equalsIgnoreCase("e"))
						{
							boolean identified = false;
							while(identified == false)
							{
								System.out.println("Please enter the product ID:");
								if(keyboard.hasNextInt())
								{
									int id = keyboard.nextInt();
									identified = true;
									keyboard.nextLine();
									boolean described = false;
									String desc = "";
									while(described == false)
									{
										System.out.println("Please enter the description:");
										desc = keyboard.nextLine();
										if(!desc.isEmpty())
										{
											described = true;
										}
										else
										{
											System.out.println("Please enter a valid description.");
										}
									}
									System.out.println("Please enter the price (optional):");
									double price = 0.0;
									String price_line = keyboard.nextLine();
									if(!price_line.isEmpty())
									{
										try
										{
											price = Double.parseDouble(price_line);
										}
										catch(NumberFormatException e)
										{
											System.out.println("There was an exception. You entered an invalid data type.");
										}
									}
									boolean y = false;
									int yr = 0;
									while(y == false)
									{
										System.out.println("Please enter the year:");
										if(keyboard.hasNextInt())
										{
											yr = keyboard.nextInt();
											keyboard.nextLine();
											y = true;
										}
										else
										{
											System.out.println("Please enter a valid year.");
										}
									}
									System.out.println("Please enter the maker (optional):");
									String maker = keyboard.nextLine();
									eStore.addProduct(id, desc, price, yr, maker);
									eStore.addHash(productIndex, desc);
									productIndex++;
									added = true;
								}
								else
								{
									System.out.println("Invalid input.\n");
									keyboard.nextLine();
								}
							}
						}
						else
						{
							System.out.println("Invalid input. Please enter either book or electronic.\n");
						}
				}
			}
			else if(answer.equalsIgnoreCase("search") || answer.equalsIgnoreCase("s"))
			{
				System.out.println("Please enter the product ID to search (optional):");
				int id = -1;
				String id_line = keyboard.nextLine();
				if(!id_line.isEmpty())
				{
					try
					{
						id = Integer.parseInt(id_line);
					}
					catch(NumberFormatException e)
					{
						System.out.println("There was an exception. You entered an invalid data type.");
					}
				}
				System.out.println("Please enter some keywords to search (optional):");
				String line = keyboard.nextLine();
				String[] keywords = line.split(" ");
				System.out.println("Please enter a time period to search (optional):");
				String timePeriod = keyboard.nextLine();
				boolean typeChosen = false;
				while(typeChosen == false)
				{
					System.out.println("Would you like to use linear, or hash search?");
					String type = keyboard.nextLine();
					if(type.equalsIgnoreCase("linear") || type.equalsIgnoreCase("l"))
					{
						eStore.searchProducts(keywords, id, timePeriod);
						typeChosen = true;
					}
					else if(type.equalsIgnoreCase("hash") || type.equalsIgnoreCase("h"))
					{
						eStore.hashSearchProducts(keywords, id, timePeriod);
						typeChosen = true;
					}
					else
					{
						System.out.println("Please enter either linear or hash.");
					}
				}
			}
			else if(answer.equalsIgnoreCase("quit") || answer.equalsIgnoreCase("q"))
			{
				quit = true;
			}
			else
			{
				System.out.println("Please enter a valid command.\n");
			}
		}
		if(!args[0].isEmpty())
		{
			try
			{
				PrintWriter fileWriter = new PrintWriter(args[0], "UTF-8");
				eStore.saveProducts(fileWriter);
				fileWriter.close();
			}
			catch(Exception e)
			{
				System.out.println("Failed to save!");
			}
		}
	}
	/*This function adds the specified product to the products ArrayList in eStoreSearch. If the product ID matches another product ID in the ArrayList, it will print an error message and return before adding the product.*/
	public void addProduct(int productID, String description, double price, int year)
	{
		int i = 0;
		while(i < products.size())
		{
			if(products.get(i).getProductID() == productID)
			{
				System.out.println("Error: productID already exists.");
				return;
			}
			i++;
		}
		Product tmp = new Product(productID, description, price, year);
		products.add(tmp);
	}

	/*This function adds the specified electronic to the products ArrayList in eStoreSearch. If the product ID matches another product ID in the ArrayList, it will print an error message and return before adding the product.*/
	public void addProduct(int productID, String description, double price, int year, String maker)
	{
		int i = 0;
		while(i < products.size())
		{
			if(products.get(i).getProductID() == productID)
			{
				System.out.println("Error: productID already exists.");
				return;
			}
			i++;
		}
		Electronic tmp = new Electronic(productID, description, price, year, maker);
		products.add(tmp);
	}
	/*This function adds the specified electronic to the products ArrayList in eStoreSearch. If the product ID matches another product ID in the ArrayList, it will print an error message and return before adding the product.*/
	public void addProduct(Electronic electronic)
	{
		int i = 0;
		while(i < products.size())
		{
			if(products.get(i).getProductID() == electronic.getProductID())
			{
				System.out.println("Error: productID already exists.");
				return;
			}
			i++;
		}
		i = 0;
		products.add(electronic);
	}

	//*This function adds the specified book to the products ArrayList in eStoreSearch. If the product ID matches another product ID in the ArrayList, it will print an error message and return before adding the product.*/
	public void addProduct(int productID, String description, double price, int year, String author, String publisher)
	{
		int i = 0;
		while(i < products.size())
		{
			if(products.get(i).getProductID() == productID)
			{
				System.out.println("Error: productID already exists.");
				return;
			}
			i++;
		}
		Book tmp = new Book(productID, description, price, year, author, publisher);
		products.add(tmp);
	}
	/*This function adds the specified book to the products ArrayList in eStoreSearch. If the product ID matches another product ID in the ArrayList, it will print an error message and return before adding the product.*/
	public void addProduct(Book book)
	{
		int i = 0;
		while(i < products.size())
		{
			if(products.get(i).getProductID() == book.getProductID())
			{
				System.out.println("Error: productID already exists.");
				return;
			}
			i++;
		}
		products.add(book);
	}
	/*This function adds the keywords in the description to the HashMap if they aren't already there, and adds the integer productIndex to each of the corresponding ArrayLists*/
	public void addHash(int productIndex, String description)
	{
		String[] keywords = description.toLowerCase().split(" ");
		int i;
		for (i = 0; i < keywords.length; i++) 
		{
			if(hashIndex.get(keywords[i]) == null) // If the keyword doesn't already exist, it creates a new space for it along with an integer arraylist
			{
				hashIndex.put(keywords[i], new ArrayList<Integer>());
			}
			hashIndex.get(keywords[i]).add(productIndex);
		}
	}
	/*This Function linearly searches the products ArrayList for products with the specified keywords, id and timePeriod*/
	public void searchProducts(String[] keywords, int id, String timePeriod)
	{
		int i = 0;
		while(i < products.size())
		{
			if((products.get(i).keyWordSearch(keywords) || (keywords.length == 1 && keywords[0].isEmpty())) && (products.get(i).getProductID() == id || id == -1) && products.get(i).isWithinTimePeriod(timePeriod))
			{
				products.get(i).printProduct();
			}
			i++;
		}
	}
	/*This function uses the HashMap to search the products ArrayList for products with the specified keywords, id and timePeriod*/
	public void hashSearchProducts(String[] keywords, int id, String timePeriod)
	{
		if((keywords.length == 1 && keywords[0].isEmpty()) || hashIndex.isEmpty())
		{
			searchProducts(keywords, id, timePeriod);
		}
		else
		{
			ArrayList<Integer> intersection = new ArrayList<Integer>();
			if(hashIndex.get(keywords[0].toLowerCase()) != null)
			{
				intersection.addAll(hashIndex.get(keywords[0].toLowerCase()));
			}
			else
			{
				searchProducts(keywords, id, timePeriod);
				return;
			}
			int i;
			for (i = 1; i < keywords.length; i++) 
			{
				if(hashIndex.get(keywords[i].toLowerCase()) != null)
				{
					// If the hashMap ArrayList doesn't contain a number from the intesection ArrayList, remove that number from the intersection ArrayList
					int n;
					for(n = 0; n < intersection.size(); n++)
					{
						if(!hashIndex.get(keywords[i].toLowerCase()).contains(intersection.get(n)))
						{
							intersection.remove(n);
						}
					}
				}
			}
			if(intersection == null)
			{
				searchProducts(keywords, id, timePeriod);
			}
			else
			{
				int x;
				for(x = 0; x < intersection.size(); x++)
				{
					if((products.get(intersection.get(x)).getProductID() == id || id == -1) && products.get(intersection.get(x)).isWithinTimePeriod(timePeriod))
					{
						products.get(intersection.get(x)).printProduct();
					}
				}
			}
		}
	}
	/*Returns the products ArrayList*/
	public ArrayList<Product> getProducts()
	{
		return products;
	}
	/*Writes the product ArrayList using the specified PrintWriter*/
	public void saveProducts(PrintWriter writer)
	{
		int i;
		for(i = 0; i < products.size(); i++)
		{
			writer.println(products.get(i).toString());
			writer.print("\n");
		}
	}
}